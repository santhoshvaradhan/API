﻿namespace JWT_Auth
{
    
        public class AuthenticatedResponse
        {
            public string? Token { get; set; }
        }
    
}
